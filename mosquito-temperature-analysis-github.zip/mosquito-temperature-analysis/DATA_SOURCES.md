# 데이터 출처 및 이용 안내

- 모기 채집 자료: 서울특별시 보건환경연구원, 서울 열린데이터광장 데이터셋 OA-22301.
  https://data.seoul.go.kr/dataList/OA-22301/F/1/datasetView.do
  원본 메타데이터에 공공누리 제1유형(출처표시)로 기재되어 있습니다.
- 기상 자료: 기상청 종관기상관측(ASOS) 일자료, 서울 관측소(108).
  https://apihub.kma.go.kr/apiList.do?seqApi=2

원본 데이터의 재배포·이용 시에는 각 제공기관의 최신 이용조건과 출처표시 요건을 확인하세요.
